export interface newsmodel{
    id : any,
    news_name : any,
    news_desc : any,
    news_img : any,
    news_detail : any
}