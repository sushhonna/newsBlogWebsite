export interface usermodel{
    id : any,
    username : any,
    password : any
}